# StudyHub — Self Study Library Management System

A professional self-study facility management system for students and graduates.
Manages study seats, students, monthly fees, owner operations, reports, digital
identity cards, notifications, and AI-powered assistance.

> **This is NOT a traditional book library.** There is no book inventory, book
> catalog, or book issue/return functionality.

---

## Current Implementation Status

**Phase: Foundation (Step 1)**

The project is in its initial foundation phase. The following has been completed:

- ✅ Project architecture defined
- ✅ Database schema designed (users, students, seats, payments, notifications)
- ✅ Professional landing page with system status indicators
- ✅ Dashboard placeholder with module overview
- ✅ Design system (CSS custom properties, brand colors, focus styles)
- ✅ Health check API endpoint
- ✅ Documentation (README, QA Report)

The following is **NOT** implemented:

- ❌ Authentication and authorization
- ❌ Student management interface
- ❌ Seat management interface
- ❌ Fee management interface
- ❌ Reports and CSV exports
- ❌ Digital ID cards
- ❌ Notifications (in-app or WhatsApp)
- ❌ AI integration
- ❌ Payment processing
- ❌ Role-based dashboards

---

## Technology Stack

| Layer          | Technology                  |
| -------------- | --------------------------- |
| Framework      | Next.js 16 (App Router)     |
| Language       | TypeScript 5                |
| Database       | PostgreSQL                  |
| ORM            | Drizzle ORM 0.45            |
| Styling        | Tailwind CSS 4              |
| Runtime        | Node.js                     |

---

## Project Directory Structure

```
self-study-library/
├── README.md                  ← This file
├── QA_REPORT.md               ← Verification checklist and results
├── package.json               ← Dependencies and scripts
├── tsconfig.json              ← TypeScript configuration
├── next.config.ts             ← Next.js configuration
├── drizzle.config.json        ← Drizzle ORM configuration
├── .env                       ← Environment variables (DATABASE_URL)
├── src/
│   ├── app/
│   │   ├── layout.tsx         ← Root layout with metadata
│   │   ├── globals.css        ← Global styles + design tokens
│   │   ├── page.tsx           ← Landing page (home)
│   │   ├── dashboard/
│   │   │   └── page.tsx       ← Dashboard placeholder
│   │   └── api/
│   │       └── health/
│   │           └── route.ts   ← Health check endpoint
│   └── db/
│       ├── index.ts           ← Database connection (pool + drizzle client)
│       └── schema.ts          ← Table definitions and relations
```

### Module Responsibilities (Planned)

| Module          | Responsibility                                            |
| --------------- | --------------------------------------------------------- |
| Authentication  | Registration, login, role-based sessions, authorization   |
| Student Mgmt    | Profiles, registration status, student information        |
| Seat Mgmt       | Fixed seat assignments, availability, conflict prevention |
| Fee Mgmt        | Monthly fees, due dates, payment history, reports         |
| Reports         | Student sheets, CSV exports, access control               |
| Digital ID      | Downloadable identity cards after login                   |
| Notifications   | In-app alerts, planned WhatsApp reminders                 |
| AI Assistance   | Backend-mediated AI with privacy-aware data handling      |

---

## How to Run

### Prerequisites

- Node.js 18+ installed
- PostgreSQL running locally (or accessible via `DATABASE_URL`)

### Steps

```bash
# 1. Install dependencies
npm install

# 2. Ensure PostgreSQL is running and DATABASE_URL in .env is correct
#    Default: postgresql://postgres:postgres@127.0.0.1:5432/app_db

# 3. Push the database schema
npx drizzle-kit push

# 4. Start the development server
npm run dev

# 5. Open http://localhost:3000
```

### Build for Production

```bash
npm run build
npm run start
```

### Environment Variables

| Variable      | Description                     | Default                                               |
| ------------- | ------------------------------- | ----------------------------------------------------- |
| DATABASE_URL  | PostgreSQL connection string    | postgresql://postgres:postgres@127.0.0.1:5432/app_db  |

---

## Database Schema

### Tables

| Table          | Purpose                                                |
| -------------- | ------------------------------------------------------ |
| users          | Authentication records with role (student/owner)       |
| students       | Extended student profile data (linked to users)        |
| seats          | Study seat catalog with status and features           |
| payments       | Monthly fee records with payment status                |
| notifications  | Notification records (in-app, future WhatsApp)         |

### Enums

| Enum               | Values                                      |
| ------------------ | ------------------------------------------- |
| user_role          | student, owner                              |
| seat_status        | available, occupied, reserved, maintenance  |
| payment_status     | paid, pending, overdue                      |
| notification_status| sent, failed, pending                       |

---

## Security

### Current Limitations

- **No authentication system exists.** There is no login, session management, or role enforcement.
- **No authorization checks.** The dashboard placeholder is publicly accessible.
- **No input validation.** No forms exist yet, but all future inputs must be validated server-side.
- **No rate limiting.** Not yet implemented.
- **No HTTPS enforcement.** Must be configured at the deployment level.

### Security Requirements for Future Backend

1. Server-side authentication (hashed passwords, secure sessions/tokens)
2. Server-side authorization (enforce student vs owner on every request)
3. Input validation and output encoding on all API routes
4. Rate limiting on authentication and API endpoints
5. Protection against SQL injection, XSS, CSRF, and other common vulnerabilities
6. Least-privilege access to student and financial records
7. No secrets in frontend code or repository
8. Appropriate logging without exposing secrets or personal data

### What This Project Will NOT Do

- Store real payment card data (use a payment processor instead)
- Claim to send real messages unless a working integration confirms it
- Expose protected data through public frontend files
- Implement fake production authentication

---

## Known Issues

- The dashboard is a structural placeholder with no real functionality
- No authentication exists — any visitor can view the dashboard page
- Database schema has been defined but not yet applied to a live database
- The health check at `/api/health` only verifies database connectivity

---

## Next Steps (Step 2 Recommendations)

1. Implement authentication (registration, login, session management)
2. Build the owner dashboard with seat management
3. Build the student dashboard with profile and fee views
4. Implement role-based access control middleware
5. Add input validation and error handling across all routes
6. Implement CSV export for reports
7. Design and generate digital ID cards
