import Link from "next/link";
import { db } from "@/db";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  let dbHealthy = false;
  try {
    await db.execute(sql`select 1`);
    dbHealthy = true;
  } catch {
    dbHealthy = false;
  }

  return (
    <div className="flex min-h-screen flex-col">
      {/* Navigation */}
      <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/80 backdrop-blur-md">
        <nav className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand-600 text-white font-bold text-sm">
              SH
            </div>
            <span className="text-lg font-semibold text-slate-900">
              StudyHub
            </span>
          </Link>
          <div className="flex items-center gap-6 text-sm font-medium text-slate-600">
            <a href="#features" className="transition-colors hover:text-brand-600">
              Features
            </a>
            <a href="#status" className="transition-colors hover:text-brand-600">
              System Status
            </a>
            <Link
              href="/dashboard"
              className="rounded-lg bg-brand-600 px-4 py-2 text-white transition-colors hover:bg-brand-700"
            >
              Dashboard
            </Link>
          </div>
        </nav>
      </header>

      {/* Hero */}
      <main className="flex-1">
        <section className="mx-auto max-w-6xl px-6 pb-24 pt-20 text-center">
          <div className="mx-auto max-w-3xl">
            <span className="inline-block rounded-full bg-brand-100 px-4 py-1.5 text-xs font-semibold tracking-wide text-brand-700 uppercase">
              Self-Study Facility Management
            </span>
            <h1 className="mt-8 text-[clamp(2.5rem,5.5vw,4rem)] font-bold leading-[1.1] tracking-tight text-slate-950">
              A Smarter Way to Manage
              <span className="text-brand-600"> Self-Study Libraries</span>
            </h1>
            <p className="mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-slate-600">
              StudyHub helps library owners manage student registrations, seat
              assignments, monthly fees, and digital identity cards — all from
              one clean, secure dashboard.
            </p>
            <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
              <Link
                href="/dashboard"
                className="rounded-xl bg-brand-600 px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-brand-600/20 transition-all hover:bg-brand-700 hover:shadow-xl"
              >
                Open Dashboard
              </Link>
              <a
                href="#features"
                className="rounded-xl border border-slate-300 bg-white px-6 py-3 text-sm font-semibold text-slate-700 transition-all hover:border-brand-300 hover:text-brand-700"
              >
                Explore Features
              </a>
            </div>
          </div>
        </section>

        {/* Features */}
        <section id="features" className="border-t border-slate-200 bg-white">
          <div className="mx-auto max-w-6xl px-6 py-20">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-slate-950">
                Built for Study Libraries
              </h2>
              <p className="mt-3 text-base text-slate-600">
                Every feature is designed for the daily operations of a
                self-study facility.
              </p>
            </div>
            <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              <FeatureCard
                icon="🪑"
                title="Seat Management"
                description="Assign fixed seats to students. Track availability, prevent conflicts, and manage floor/section layouts."
              />
              <FeatureCard
                icon="🎓"
                title="Student Profiles"
                description="Maintain detailed student records including contact, guardian info, education, and registration dates."
              />
              <FeatureCard
                icon="💰"
                title="Fee Tracking"
                description="Monthly fee records with due-date tracking, payment history, and outstanding balance reports."
              />
              <FeatureCard
                icon="📊"
                title="Reports & Exports"
                description="Generate student sheets and CSV exports with appropriate access control for owners."
              />
              <FeatureCard
                icon="🪪"
                title="Digital ID Cards"
                description="Downloadable student identity cards accessible only to the authorized student and owner."
              />
              <FeatureCard
                icon="🔔"
                title="Notifications"
                description="In-app notifications with planned WhatsApp reminder integration and honest delivery status."
              />
            </div>
          </div>
        </section>

        {/* System Status */}
        <section id="status" className="border-t border-slate-200">
          <div className="mx-auto max-w-6xl px-6 py-20">
            <h2 className="text-center text-3xl font-bold text-slate-950">
              System Status
            </h2>
            <div className="mt-10 mx-auto max-w-md">
              <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                <StatusRow
                  label="Database Connection"
                  status={dbHealthy ? "connected" : "disconnected"}
                  ok={dbHealthy}
                />
                <StatusRow
                  label="Web Server"
                  status="running"
                  ok={true}
                />
                <StatusRow
                  label="Authentication"
                  status="pending implementation"
                  ok={null}
                />
                <StatusRow
                  label="Payment Processing"
                  status="pending implementation"
                  ok={null}
                />
                <StatusRow
                  label="WhatsApp Notifications"
                  status="pending implementation"
                  ok={null}
                />
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white">
        <div className="mx-auto max-w-6xl px-6 py-8 text-center text-sm text-slate-500">
          © {new Date().getFullYear()} StudyHub — Self Study Library Management
          System. Foundation phase.
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({
  icon,
  title,
  description,
}: {
  icon: string;
  title: string;
  description: string;
}) {
  return (
    <div className="group rounded-2xl border border-slate-200 bg-slate-50 p-6 transition-all hover:border-brand-200 hover:bg-white hover:shadow-md">
      <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-white text-2xl shadow-sm border border-slate-100">
        {icon}
      </div>
      <h3 className="mt-4 text-base font-semibold text-slate-900">{title}</h3>
      <p className="mt-2 text-sm leading-relaxed text-slate-600">
        {description}
      </p>
    </div>
  );
}

function StatusRow({
  label,
  status,
  ok,
}: {
  label: string;
  status: string;
  ok: boolean | null;
}) {
  const color =
    ok === true
      ? "bg-green-500"
      : ok === false
        ? "bg-red-500"
        : "bg-amber-400";

  return (
    <div className="flex items-center justify-between border-b border-slate-100 py-3 last:border-b-0">
      <span className="text-sm font-medium text-slate-700">{label}</span>
      <span className="flex items-center gap-2 text-sm">
        <span className={`h-2 w-2 rounded-full ${color}`} />
        <span className="text-slate-600">{status}</span>
      </span>
    </div>
  );
}
