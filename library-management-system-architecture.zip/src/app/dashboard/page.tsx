import Link from "next/link";

/**
 * Dashboard placeholder page.
 *
 * In future steps this will host the role-aware dashboard:
 *   - Owner dashboard: full CRUD, reports, seat management, fee management.
 *   - Student dashboard: profile view, payment history, digital ID card.
 *
 * Currently it serves as a navigation hub showing what will be built.
 */
export default function DashboardPage() {
  const modules = [
    {
      title: "Authentication",
      description: "Student registration, login, and owner access control.",
      status: "planned",
    },
    {
      title: "Student Management",
      description: "Profiles, registration status, and student information.",
      status: "planned",
    },
    {
      title: "Seat Management",
      description: "Fixed seat assignments, availability, and conflict prevention.",
      status: "planned",
    },
    {
      title: "Fee Management",
      description: "Monthly fees, due-date tracking, payment history, and reports.",
      status: "planned",
    },
    {
      title: "Reports",
      description: "Student sheets and downloadable CSV exports for owners.",
      status: "planned",
    },
    {
      title: "Digital ID Cards",
      description: "Downloadable identity cards after secure login.",
      status: "planned",
    },
    {
      title: "Notifications",
      description: "In-app alerts with planned WhatsApp reminders.",
      status: "planned",
    },
    {
      title: "AI Assistance",
      description: "Backend-mediated AI support with privacy-aware data handling.",
      status: "planned",
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand-600 text-white font-bold text-sm">
              SH
            </div>
            <span className="text-lg font-semibold text-slate-900">
              StudyHub
            </span>
          </Link>
          <Link
            href="/"
            className="text-sm font-medium text-slate-600 transition-colors hover:text-brand-600"
          >
            ← Back to Home
          </Link>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-12">
        <div className="mb-10">
          <h1 className="text-3xl font-bold text-slate-950">Dashboard</h1>
          <p className="mt-2 text-base text-slate-600">
            Module overview — authentication required for access to each module.
          </p>
        </div>

        <div className="mb-8 rounded-xl border border-amber-200 bg-amber-50 p-5">
          <p className="text-sm font-semibold text-amber-800">
            ⚠ Foundation Phase — Authentication Not Yet Implemented
          </p>
          <p className="mt-1 text-sm text-amber-700">
            This page is a structural placeholder. No real dashboards, data, or
            protected routes exist yet. All modules below are planned but not
            functional.
          </p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {modules.map((mod) => (
            <div
              key={mod.title}
              className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-base font-semibold text-slate-900">
                  {mod.title}
                </h3>
                <span className="rounded-full bg-slate-100 px-2.5 py-0.5 text-xs font-medium text-slate-500">
                  {mod.status}
                </span>
              </div>
              <p className="mt-2 text-sm leading-relaxed text-slate-600">
                {mod.description}
              </p>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
