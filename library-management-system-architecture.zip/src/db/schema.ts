import { relations } from "drizzle-orm";
import {
  boolean,
  date,
  integer,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";

/**
 * Self Study Library — Database Schema
 *
 * This schema defines the foundational data model for the StudyHub
 * self-study library management system. It is designed to support:
 *   - Multi-role authentication (student / owner)
 *   - Fixed seat assignment with conflict prevention
 *   - Monthly fee tracking with due-date management
 *   - Digital identity cards
 *   - Notification records
 *   - Audit timestamps on every record
 *
 * Security note: This schema stores hashed passwords only. No plaintext
 * credentials, API keys, or payment card data belong in this database.
 */

// ── Enums ──────────────────────────────────────────────────────────────────────

export const userRoleEnum = pgEnum("user_role", ["student", "owner"]);
export const seatStatusEnum = pgEnum("seat_status", [
  "available",
  "occupied",
  "reserved",
  "maintenance",
]);
export const paymentStatusEnum = pgEnum("payment_status", [
  "paid",
  "pending",
  "overdue",
]);
export const notificationStatusEnum = pgEnum("notification_status", [
  "sent",
  "failed",
  "pending",
]);

// ── Users & Authentication ─────────────────────────────────────────────────────

export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  fullName: varchar("full_name", { length: 160 }).notNull(),
  phone: varchar("phone", { length: 20 }),
  role: userRoleEnum("role").notNull().default("student"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

// ── Students ───────────────────────────────────────────────────────────────────

export const students = pgTable("students", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  guardianName: varchar("guardian_name", { length: 160 }),
  guardianPhone: varchar("guardian_phone", { length: 20 }),
  address: text("address"),
  education: varchar("education", { length: 200 }),
  notes: text("notes"),
  registrationDate: date("registration_date").notNull().defaultNow(),
  seatId: uuid("seat_id").references(() => seats.id, {
    onDelete: "set null",
  }),
});

// ── Seats ──────────────────────────────────────────────────────────────────────

export const seats = pgTable("seats", {
  id: uuid("id").primaryKey().defaultRandom(),
  seatNumber: varchar("seat_number", { length: 20 }).notNull().unique(),
  floor: varchar("floor", { length: 20 }).notNull().default("1"),
  section: varchar("section", { length: 20 }).notNull().default("A"),
  status: seatStatusEnum("status").notNull().default("available"),
  hasChargingPort: boolean("has_charging_port").notNull().default(false),
  hasLamp: boolean("has_lamp").notNull().default(false),
});

// ── Fee / Payments ─────────────────────────────────────────────────────────────

export const payments = pgTable("payments", {
  id: uuid("id").primaryKey().defaultRandom(),
  studentId: uuid("student_id")
    .notNull()
    .references(() => students.id, { onDelete: "cascade" }),
  amount: integer("amount").notNull(), // stored in smallest currency unit (paise)
  month: varchar("month", { length: 20 }).notNull(), // e.g. "2025-06"
  dueDate: date("due_date").notNull(),
  paidDate: date("paid_date"),
  status: paymentStatusEnum("status").notNull().default("pending"),
  recordedBy: uuid("recorded_by").references(() => users.id, {
    onDelete: "set null",
  }),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

// ── Notifications ──────────────────────────────────────────────────────────────

export const notifications = pgTable("notifications", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  channel: varchar("channel", { length: 20 }).notNull().default("in_app"),
  title: varchar("title", { length: 200 }).notNull(),
  body: text("body").notNull(),
  status: notificationStatusEnum("status").notNull().default("pending"),
  sentAt: timestamp("sent_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

// ── Relations ──────────────────────────────────────────────────────────────────

export const usersRelations = relations(users, ({ one }) => ({
  student: one(students, {
    fields: [users.id],
    references: [students.userId],
  }),
}));

export const studentsRelations = relations(students, ({ one, many }) => ({
  user: one(users, {
    fields: [students.userId],
    references: [users.id],
  }),
  seat: one(seats, {
    fields: [students.seatId],
    references: [seats.id],
  }),
  payments: many(payments),
}));

export const seatsRelations = relations(seats, ({ many }) => ({
  students: many(students),
}));

export const paymentsRelations = relations(payments, ({ one }) => ({
  student: one(students, {
    fields: [payments.studentId],
    references: [students.id],
  }),
  recordedByUser: one(users, {
    fields: [payments.recordedBy],
    references: [users.id],
  }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, {
    fields: [notifications.userId],
    references: [users.id],
  }),
}));

// ── Type exports ───────────────────────────────────────────────────────────────

export type User = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;
export type Student = typeof students.$inferSelect;
export type NewStudent = typeof students.$inferInsert;
export type Seat = typeof seats.$inferSelect;
export type NewSeat = typeof seats.$inferInsert;
export type Payment = typeof payments.$inferSelect;
export type NewPayment = typeof payments.$inferInsert;
export type Notification = typeof notifications.$inferSelect;
export type NewNotification = typeof notifications.$inferInsert;
